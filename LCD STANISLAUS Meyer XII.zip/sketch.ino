#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);
const int tombolMerah = 4;
const int tombolHijau = 2;

  // Hitungee
int hitungan = 0;
  // Biar gak ketabrak per click button, ada delay sebelum dihitung neken
bool lastMerah = HIGH;
bool lastHijau = HIGH;
unsigned long debounceDelay = 50;
unsigned long lastDebounceMerah = 0;
unsigned long lastDebounceHijau = 0;

void setup() {
  // Starter LCD
  lcd.init();
  lcd.backlight();
  
  // Setup pin tombol sebagai input dengan pull-up resistor
  pinMode(tombolMerah, INPUT_PULLUP);
  pinMode(tombolHijau, INPUT_PULLUP);
  
  // Tampilkan teks awal di baris pertama
  lcd.setCursor(0, 0);
  lcd.print("SMAK Stanislaus");
  hitunge();
}

void loop() {
  bool skrgMerah = digitalRead(tombolMerah);
  bool skrgHijau = digitalRead(tombolHijau);
  
  //debounce=delay antar hitungaangka, 
  if (skrgMerah == LOW && lastMerah == HIGH) {
    if ((millis() - lastDebounceMerah) > debounceDelay) {
      hitungan--;
      hitunge();
      lastDebounceMerah = millis();
    }
  }
  
  if (skrgHijau == LOW && lastHijau == HIGH) {
    if ((millis() - lastDebounceHijau) > debounceDelay) {
      hitungan++;
      hitunge();
      lastDebounceHijau = millis();
    }
  }
  
  lastMerah = skrgMerah;
  lastHijau = skrgHijau;
  
  delay(10);
}

void hitunge() {
  lcd.setCursor(0, 1);
  lcd.print("                "); 
  // NGresikno layar ne

  lcd.setCursor(0, 1);
  lcd.print("Hitung: ");
  lcd.print(hitungan);
}